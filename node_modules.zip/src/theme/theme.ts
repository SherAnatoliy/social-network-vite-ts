import { color } from "./color";
export const theme = {
  color:{...color}
}
export type Theme = typeof theme;